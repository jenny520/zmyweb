module.exports = function(){
    var content = [
        '',
        '                                           ',
        '         ' + '`-:////:-`'.yellow.bold + '                        ',
        '      ' + './ossssssssss+-'.yellow.bold + '                      ',
        '    ' + '-+sssssssssssssss+`'.yellow.bold + '                    ',
        '   ' + '.-...-+ssssssssssss/'.yellow.bold + '        .`          ',
        '          ' + ':ssssssssssso`'.yellow.bold + '      -o+`         ',
        '          ' + '.ossssssssss/'.yellow.bold + '       +ss+-.       ',
        '         ' + '`+ssssssssss+`'.yellow.bold + '     ./osssss+:`    ',
        '        ' + '-ossssssssso:`'.yellow.bold + ' `.-/ossssssssss+`   ',
        '      ' + '.+sssssssss+:`'.yellow.bold + '  `.--:/+osssssssss/   ',
        '    ' + '`:osssssso+:``'.yellow.bold + '.-::/+++/-.'.white.bold + '`.:+ossssso`  ',
        '   ' + '`+sssssso:``'.yellow.bold + '' + '-:/+//:-'.red.bold + '`.:+sso/-`'.white.bold + '`.-::-.   ',
        '   ' + ':ssssss/`'.yellow.bold + './/:---:/oso+-`'.red.bold + '.+sssoo+//:-`'.white.bold + '   ',
        '  ' + '`osssss/ `'.yellow.bold + '.' + '``-:::-``'.blue.bold + '.+ss+.'.red.bold + ' :osssso//::`'.white.bold + '  ',
        '  ' + '`osssso.'.yellow.bold + '  ' + '`/osoooso/`'.blue.bold + ' /sso.'.red.bold + ' `...`'.white.bold + '        ',
        '   ' + '/sssso.'.yellow.bold + ' ' + '`+ss:```/ss/'.blue.bold + ' `oss/'.red.bold + '              ',
        '   ' + '`+ssss:'.yellow.bold + ' ' + '`oso.   -ss+'.blue.bold + ' `oss/'.red.bold + '              ',
        '    ' + '`/ssso.'.yellow.bold + ' ' + '-oso+/+oso.'.blue.bold + ' -sss:'.red.bold + '              ',
        '      ' + './oso/`'.yellow.bold + '' + '`-/+o+/-`'.blue.bold + '`:osss+/:-`'.red.bold + '          ',
        '        ' + '`.-//:.`'.yellow.bold + '   ' + '`'.blue.bold + '.:++++++++//:`'.red.bold + '         ',
        '',
        '              v' + fis.cli.info.version,
        ''
    ].join('\n');
    console.log(content);
};